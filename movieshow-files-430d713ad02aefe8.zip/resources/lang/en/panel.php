<?php

return [
    'site_title' => 'MovieShow',
];
